#!/usr/bin/python3
from PyQt5.QtWidgets import QDialog, QApplication
import sys
import os
from phoneUi import *
from twilio.rest import Client
import time
from gtts import gTTS
from pygame import mixer

operator = ""

class LoginPage(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Phone()
        self.ui.setupUi(self)
        self.ui.n1.clicked.connect(lambda:self.NumberPrinter(1))
        self.ui.n2.clicked.connect(lambda:self.NumberPrinter(2))
        self.ui.n3.clicked.connect(lambda:self.NumberPrinter(3))
        self.ui.n4.clicked.connect(lambda:self.NumberPrinter(4))
        self.ui.n5.clicked.connect(lambda:self.NumberPrinter(5))
        self.ui.n6.clicked.connect(lambda:self.NumberPrinter(6))
        self.ui.n7.clicked.connect(lambda:self.NumberPrinter(7))
        self.ui.n8.clicked.connect(lambda:self.NumberPrinter(8))
        self.ui.n9.clicked.connect(lambda:self.NumberPrinter(9))
        self.ui.n0.clicked.connect(lambda:self.NumberPrinter(0))
        self.ui.plus.clicked.connect(lambda:self.NumberPrinter("+"))
        self.ui.star.clicked.connect(lambda:self.NumberPrinter("*"))
        self.ui.makecall.clicked.connect(self.MakeCall)

        self.ui.NumberEraser.setFlat(True)
        self.ui.n0.setFlat(True)
        self.ui.n1.setFlat(True)
        self.ui.n2.setFlat(True)
        self.ui.n3.setFlat(True)
        self.ui.n4.setFlat(True)
        self.ui.n5.setFlat(True)
        self.ui.n6.setFlat(True)
        self.ui.n7.setFlat(True)
        self.ui.n8.setFlat(True)
        self.ui.n9.setFlat(True)
        self.ui.star.setFlat(True)
        self.ui.plus.setFlat(True)
        self.ui.NumberEraser.clicked.connect(self.NumberEaraser)

        self.ui.Number_Error.hide()
        self.show()

    def NumberPrinter(self, Number):
        global operator
        self.ui.Number_Error.hide()
        operator = operator + str(Number)
        self.ui.Number_Printer.setText(operator)

    def NumberEaraser(self):
        global operator
        operator= ""
        self.ui.Number_Printer.setText("")

    def MakeCall(self):
        number = self.ui.Number_Printer.text()
        if(number == ""):
            self.ui.Number_Error.show()

        else:
            try:
                From_Number = "+18577634851"
                To_Number = number
                Src_Path = "http://www.vothla.com/Twilio_Demo.xml   "
                client = Client("AC61b5dc11d40f9a1520a02701becaa19b", "a1cf61c8dcce2186e4867f41cb4e6aa6")
                client.calls.create(to = To_Number, from_ = From_Number, url = Src_Path, method = 'GET')
                self.ui.Number_Error.hide()
            except Exception:
                self.ui.Number_Error.show()
                mixer.init()
                mixer.music.load("/usr/share/app/Callingapp/Phone_Call_error.mp3")
                mixer.music.play()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    w = LoginPage()
    w.show()
    sys.exit(app.exec_())