# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'phoneUi.ui'
#
# Created by: PyQt5 UI code generator 5.12.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Phone(object):
    def setupUi(self, Phone):
        Phone.setObjectName("Phone")
        Phone.resize(770, 1310)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("/usr/share/app/Callingapp/phone.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Phone.setWindowIcon(icon)
        Phone.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.verticalLayout = QtWidgets.QVBoxLayout(Phone)
        self.verticalLayout.setObjectName("verticalLayout")
        self.Frame = QtWidgets.QFrame(Phone)
        self.Frame.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.Frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.Frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.Frame.setObjectName("Frame")
        self.gridLayout = QtWidgets.QGridLayout(self.Frame)
        self.gridLayout.setObjectName("gridLayout")
        self.NumberEraser = QtWidgets.QPushButton(self.Frame)
        self.NumberEraser.setFocusPolicy(QtCore.Qt.NoFocus)
        self.NumberEraser.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.NumberEraser.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("/usr/share/app/Callingapp/backbutton.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.NumberEraser.setIcon(icon1)
        self.NumberEraser.setIconSize(QtCore.QSize(100, 100))
        self.NumberEraser.setFlat(True)
        self.NumberEraser.setObjectName("NumberEraser")
        self.gridLayout.addWidget(self.NumberEraser, 2, 2, 1, 1)
        self.n1 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n1.setFont(font)
        self.n1.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n1.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n1.setIconSize(QtCore.QSize(179, 200))
        self.n1.setAutoDefault(False)
        self.n1.setDefault(False)
        self.n1.setFlat(True)
        self.n1.setObjectName("n1")
        self.gridLayout.addWidget(self.n1, 3, 0, 1, 1)
        self.n4 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n4.setFont(font)
        self.n4.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n4.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n4.setIconSize(QtCore.QSize(179, 200))
        self.n4.setFlat(True)
        self.n4.setObjectName("n4")
        self.gridLayout.addWidget(self.n4, 4, 0, 1, 1)
        self.star = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.star.setFont(font)
        self.star.setFocusPolicy(QtCore.Qt.NoFocus)
        self.star.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.star.setIconSize(QtCore.QSize(179, 200))
        self.star.setFlat(True)
        self.star.setObjectName("star")
        self.gridLayout.addWidget(self.star, 6, 0, 1, 1)
        self.plus = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.plus.setFont(font)
        self.plus.setFocusPolicy(QtCore.Qt.NoFocus)
        self.plus.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.plus.setIconSize(QtCore.QSize(179, 200))
        self.plus.setFlat(True)
        self.plus.setObjectName("plus")
        self.gridLayout.addWidget(self.plus, 6, 2, 1, 1)
        self.n9 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n9.setFont(font)
        self.n9.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n9.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n9.setIconSize(QtCore.QSize(179, 200))
        self.n9.setFlat(True)
        self.n9.setObjectName("n9")
        self.gridLayout.addWidget(self.n9, 5, 2, 1, 1)
        self.n3 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n3.setFont(font)
        self.n3.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n3.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n3.setIconSize(QtCore.QSize(179, 200))
        self.n3.setFlat(True)
        self.n3.setObjectName("n3")
        self.gridLayout.addWidget(self.n3, 3, 2, 1, 1)
        self.n2 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n2.setFont(font)
        self.n2.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n2.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n2.setIconSize(QtCore.QSize(179, 200))
        self.n2.setFlat(True)
        self.n2.setObjectName("n2")
        self.gridLayout.addWidget(self.n2, 3, 1, 1, 1)
        self.makecall = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(60)
        self.makecall.setFont(font)
        self.makecall.setFocusPolicy(QtCore.Qt.NoFocus)
        self.makecall.setStyleSheet("background-color: rgb(0, 51, 239);\n"
"color: rgb(255, 255, 255);")
        self.makecall.setText("")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("/usr/share/app/Callingapp/make call.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.makecall.setIcon(icon2)
        self.makecall.setIconSize(QtCore.QSize(200, 150))
        self.makecall.setObjectName("makecall")
        self.gridLayout.addWidget(self.makecall, 7, 0, 1, 3)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 1, 1, 1, 1)
        self.n6 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n6.setFont(font)
        self.n6.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n6.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n6.setIconSize(QtCore.QSize(179, 200))
        self.n6.setFlat(True)
        self.n6.setObjectName("n6")
        self.gridLayout.addWidget(self.n6, 4, 2, 1, 1)
        self.n0 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n0.setFont(font)
        self.n0.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n0.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n0.setIconSize(QtCore.QSize(179, 200))
        self.n0.setFlat(True)
        self.n0.setObjectName("n0")
        self.gridLayout.addWidget(self.n0, 6, 1, 1, 1)
        self.Number_Error = QtWidgets.QLabel(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(18)
        self.Number_Error.setFont(font)
        self.Number_Error.setObjectName("Number_Error")
        self.gridLayout.addWidget(self.Number_Error, 0, 1, 1, 1)
        self.n5 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n5.setFont(font)
        self.n5.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n5.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n5.setIconSize(QtCore.QSize(179, 200))
        self.n5.setFlat(True)
        self.n5.setObjectName("n5")
        self.gridLayout.addWidget(self.n5, 4, 1, 1, 1)
        self.n7 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n7.setFont(font)
        self.n7.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n7.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n7.setIconSize(QtCore.QSize(179, 200))
        self.n7.setFlat(True)
        self.n7.setObjectName("n7")
        self.gridLayout.addWidget(self.n7, 5, 0, 1, 1)
        self.n8 = QtWidgets.QPushButton(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(120)
        self.n8.setFont(font)
        self.n8.setFocusPolicy(QtCore.Qt.NoFocus)
        self.n8.setStyleSheet("background-color: rgb(45, 45, 45);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n8.setIconSize(QtCore.QSize(179, 200))
        self.n8.setFlat(True)
        self.n8.setObjectName("n8")
        self.gridLayout.addWidget(self.n8, 5, 1, 1, 1)
        self.Number_Printer = QtWidgets.QLabel(self.Frame)
        font = QtGui.QFont()
        font.setPointSize(40)
        self.Number_Printer.setFont(font)
        self.Number_Printer.setText("")
        self.Number_Printer.setObjectName("Number_Printer")
        self.gridLayout.addWidget(self.Number_Printer, 2, 0, 1, 2)
        self.verticalLayout.addWidget(self.Frame)

        self.retranslateUi(Phone)
        QtCore.QMetaObject.connectSlotsByName(Phone)

    def retranslateUi(self, Phone):
        _translate = QtCore.QCoreApplication.translate
        Phone.setWindowTitle(_translate("Phone", "Phone"))
        self.n1.setText(_translate("Phone", "1"))
        self.n4.setText(_translate("Phone", "4"))
        self.star.setText(_translate("Phone", "*"))
        self.plus.setText(_translate("Phone", "+"))
        self.n9.setText(_translate("Phone", "9"))
        self.n3.setText(_translate("Phone", "3"))
        self.n2.setText(_translate("Phone", "2"))
        self.n6.setText(_translate("Phone", "6"))
        self.n0.setText(_translate("Phone", "0"))
        self.Number_Error.setText(_translate("Phone", "Please enter valid number"))
        self.n5.setText(_translate("Phone", "5"))
        self.n7.setText(_translate("Phone", "7"))
        self.n8.setText(_translate("Phone", "8"))


