# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'calling.ui'
#
# Created by: PyQt5 UI code generator 5.12.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Phone(object):
    def setupUi(self, Phone):
        Phone.setObjectName("Phone")
        Phone.resize(768, 1362)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("phone.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        Phone.setWindowIcon(icon)
        Phone.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.makecall = QtWidgets.QPushButton(Phone)
        self.makecall.setGeometry(QtCore.QRect(0, 1170, 771, 141))
        font = QtGui.QFont()
        font.setPointSize(20)
        self.makecall.setFont(font)
        self.makecall.setStyleSheet("background-color: rgb(8, 0, 255);\n"
"color: rgb(255, 255, 255);")
        self.makecall.setObjectName("makecall")
        self.star = QtWidgets.QPushButton(Phone)
        self.star.setGeometry(QtCore.QRect(0, 990, 251, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.star.setFont(font)
        self.star.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.star.setObjectName("star")
        self.n0 = QtWidgets.QPushButton(Phone)
        self.n0.setGeometry(QtCore.QRect(250, 990, 271, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n0.setFont(font)
        self.n0.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n0.setObjectName("n0")
        self.plus = QtWidgets.QPushButton(Phone)
        self.plus.setGeometry(QtCore.QRect(520, 990, 251, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.plus.setFont(font)
        self.plus.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.plus.setObjectName("plus")
        self.n7 = QtWidgets.QPushButton(Phone)
        self.n7.setGeometry(QtCore.QRect(0, 810, 251, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n7.setFont(font)
        self.n7.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n7.setObjectName("n7")
        self.n8 = QtWidgets.QPushButton(Phone)
        self.n8.setGeometry(QtCore.QRect(250, 810, 271, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n8.setFont(font)
        self.n8.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n8.setObjectName("n8")
        self.n9 = QtWidgets.QPushButton(Phone)
        self.n9.setGeometry(QtCore.QRect(520, 810, 251, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n9.setFont(font)
        self.n9.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n9.setObjectName("n9")
        self.n2 = QtWidgets.QPushButton(Phone)
        self.n2.setGeometry(QtCore.QRect(250, 450, 271, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n2.setFont(font)
        self.n2.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n2.setObjectName("n2")
        self.n5 = QtWidgets.QPushButton(Phone)
        self.n5.setGeometry(QtCore.QRect(250, 630, 271, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n5.setFont(font)
        self.n5.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n5.setObjectName("n5")
        self.n3 = QtWidgets.QPushButton(Phone)
        self.n3.setGeometry(QtCore.QRect(520, 450, 251, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n3.setFont(font)
        self.n3.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n3.setObjectName("n3")
        self.n6 = QtWidgets.QPushButton(Phone)
        self.n6.setGeometry(QtCore.QRect(520, 630, 251, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n6.setFont(font)
        self.n6.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n6.setObjectName("n6")
        self.n1 = QtWidgets.QPushButton(Phone)
        self.n1.setGeometry(QtCore.QRect(0, 450, 251, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n1.setFont(font)
        self.n1.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n1.setAutoDefault(False)
        self.n1.setDefault(False)
        self.n1.setFlat(False)
        self.n1.setObjectName("n1")
        self.n4 = QtWidgets.QPushButton(Phone)
        self.n4.setGeometry(QtCore.QRect(0, 630, 251, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.n4.setFont(font)
        self.n4.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.n4.setObjectName("n4")
        self.NumberEraser = QtWidgets.QPushButton(Phone)
        self.NumberEraser.setGeometry(QtCore.QRect(520, 270, 251, 181))
        font = QtGui.QFont()
        font.setPointSize(30)
        self.NumberEraser.setFont(font)
        self.NumberEraser.setStyleSheet("background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"")
        self.NumberEraser.setText("")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("/usr/share/app/Callingapp/backbutton.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.NumberEraser.setIcon(icon1)
        self.NumberEraser.setIconSize(QtCore.QSize(100, 100))
        self.NumberEraser.setFlat(True)
        self.NumberEraser.setObjectName("NumberEraser")
        self.NumberPrint = QtWidgets.QLabel(Phone)
        self.NumberPrint.setGeometry(QtCore.QRect(3, 260, 511, 181))
        font = QtGui.QFont()
        font.setPointSize(40)
        self.NumberPrint.setFont(font)
        self.NumberPrint.setText("")
        self.NumberPrint.setObjectName("NumberPrint")
        self.Number_Error = QtWidgets.QLabel(Phone)
        self.Number_Error.setGeometry(QtCore.QRect(250, 10, 281, 20))
        font = QtGui.QFont()
        font.setPointSize(18)
        self.Number_Error.setFont(font)
        self.Number_Error.setObjectName("Number_Error")
        self.NumberEraser.raise_()
        self.n1.raise_()
        self.n2.raise_()
        self.n3.raise_()
        self.n4.raise_()
        self.n5.raise_()
        self.n6.raise_()
        self.n7.raise_()
        self.n8.raise_()
        self.n9.raise_()
        self.star.raise_()
        self.n0.raise_()
        self.plus.raise_()
        self.makecall.raise_()
        self.NumberPrint.raise_()
        self.Number_Error.raise_()

        self.retranslateUi(Phone)
        QtCore.QMetaObject.connectSlotsByName(Phone)

    def retranslateUi(self, Phone):
        _translate = QtCore.QCoreApplication.translate
        Phone.setWindowTitle(_translate("Phone", "Phone "))
        self.makecall.setText(_translate("Phone", "CALL"))
        self.star.setText(_translate("Phone", "*"))
        self.n0.setText(_translate("Phone", "0"))
        self.plus.setText(_translate("Phone", "+"))
        self.n7.setText(_translate("Phone", "7"))
        self.n8.setText(_translate("Phone", "8"))
        self.n9.setText(_translate("Phone", "9"))
        self.n2.setText(_translate("Phone", "2"))
        self.n5.setText(_translate("Phone", "5"))
        self.n3.setText(_translate("Phone", "3"))
        self.n6.setText(_translate("Phone", "6"))
        self.n1.setText(_translate("Phone", "1"))
        self.n4.setText(_translate("Phone", "4"))
        self.Number_Error.setText(_translate("Phone", "Please enter valid number"))


