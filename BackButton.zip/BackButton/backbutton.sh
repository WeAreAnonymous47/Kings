#!/bin/bash
xdotool key Escape
xdotool key Ctrl+Left
xdotool key Alt+Left


