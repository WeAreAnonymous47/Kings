#!/usr/bin/python3
from PyQt5.QtWidgets import QDialog, QApplication
import sys
from Calculator import *

operator = ""

class Calci(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Calculator()
        self.ui.setupUi(self)
        self.ui.c.clicked.connect(self.NumberEaraser)
        self.ui.Division.clicked.connect(lambda:self.NumberPrinter("/"))
        self.ui.Adition.clicked.connect(lambda:self.NumberPrinter("+"))
        self.ui.Multiplecation.clicked.connect(lambda:self.NumberPrinter("*"))
        self.ui.Subtraction.clicked.connect(lambda:self.NumberPrinter("-"))
        self.ui.Equals.clicked.connect(self.Equal)
        self.ui.a1.clicked.connect(lambda:self.NumberPrinter(1))
        self.ui.a2.clicked.connect(lambda:self.NumberPrinter(2))
        self.ui.a3.clicked.connect(lambda:self.NumberPrinter(3))
        self.ui.a4.clicked.connect(lambda:self.NumberPrinter(4))
        self.ui.a5.clicked.connect(lambda:self.NumberPrinter(5))
        self.ui.a6.clicked.connect(lambda:self.NumberPrinter(6))
        self.ui.a7.clicked.connect(lambda:self.NumberPrinter(7))
        self.ui.a8.clicked.connect(lambda:self.NumberPrinter(8))
        self.ui.a9.clicked.connect(lambda:self.NumberPrinter(9))
        self.ui.a0.clicked.connect(lambda:self.NumberPrinter(0))
        self.ui.Point.clicked.connect(lambda:self.NumberPrinter("."))
        self.show()

    def NumberPrinter(self, Number):
        global operator
        operator = operator + str(Number)
        self.ui.Number_Display.setText(operator)

    def NumberEaraser(self):
        global operator
        operator= ""
        self.ui.Number_Display.setText("")

    def Equal(self):
        global operator
        semup = str(eval(operator))
        self.ui.Number_Display.setText(semup)
        operator=""

if __name__ == '__main__':
    app = QApplication(sys.argv)
    w = Calci()
    w.show()
    sys.exit(app.exec_())
