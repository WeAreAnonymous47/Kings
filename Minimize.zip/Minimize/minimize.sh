#!/bin/bash
xdotool getactivewindow windowminimize
