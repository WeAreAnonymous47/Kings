#!/bin/bash
xdotool key super+a

